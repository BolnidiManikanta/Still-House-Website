import PortfolioExperience from '@/components/portfolio/PortfolioExperience'

export default function Page() {
  return <PortfolioExperience />
}
