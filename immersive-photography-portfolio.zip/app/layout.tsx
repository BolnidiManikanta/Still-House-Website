import type { Metadata, Viewport } from 'next'
import './globals.css'

export const metadata: Metadata = {
  title: 'Elena Voss — Visual Stories',
  description: 'An immersive photography archive by Elena Voss. Selected images, places and moments.',
}
export const viewport: Viewport = { width: 'device-width', initialScale: 1, themeColor: '#e8e8e5' }

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en" className="bg-[#e8e8e5]"><body className="antialiased">{children}</body></html>
}
