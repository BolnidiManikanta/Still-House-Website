import React, { useState, useEffect } from 'react';
import Lenis from 'lenis';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { DynamicBackground } from './components/DynamicBackground';
import { CustomCursor } from './components/CustomCursor';
import { Navbar } from './components/Navbar';
import { HeroSection } from './components/HeroSection';
import { CinematicImageBanner } from './components/CinematicImageBanner';
import { ContactSection } from './components/ContactSection';
import { ReviewsSlider } from './components/ReviewsSlider';
import { FinalCTA } from './components/FinalCTA';
import { Footer } from './components/Footer';
import { RatingModal } from './components/RatingModal';
import { DynamicActionButton } from './components/DynamicActionButton';
import { INITIAL_REVIEWS, PHOTOGRAPHY_CATEGORIES } from './data/initialData';
import { PhotographyRating, ShootCategory } from './types';

gsap.registerPlugin(ScrollTrigger);

export default function App() {
  const [reviews, setReviews] = useState<PhotographyRating[]>(() => {
    try {
      const saved = localStorage.getItem('apex_photography_reviews');
      if (saved) {
        return JSON.parse(saved);
      }
    } catch (e) {
      console.warn('Failed to load reviews from localStorage', e);
    }
    return INITIAL_REVIEWS;
  });

  const [isRatingModalOpen, setIsRatingModalOpen] = useState(false);
  const [activeSection, setActiveSection] = useState<'contact' | 'reviews'>('contact');
  const [selectedCategory, setSelectedCategory] = useState<ShootCategory>('portrait');

  // Initialize Lenis Smooth Scroll with GSAP ScrollTrigger Synchronization (Requirement #21)
  useEffect(() => {
    let lenis: Lenis | null = null;

    try {
      lenis = new Lenis({
        duration: 1.15,
        easing: (t) => Math.min(1, 1.001 - Math.pow(2, -10 * t)),
        orientation: 'vertical',
        smoothWheel: true,
      });

      const onLenisScroll = () => {
        ScrollTrigger.update();
      };
      lenis.on('scroll', onLenisScroll);

      const tickerCallback = (time: number) => {
        lenis?.raf(time * 1000);
      };
      gsap.ticker.add(tickerCallback);
      gsap.ticker.lagSmoothing(0);

      return () => {
        gsap.ticker.remove(tickerCallback);
        lenis?.destroy();
      };
    } catch (err) {
      console.warn('Lenis smooth scroll initialization skipped', err);
    }
  }, []);

  // Save reviews to localStorage whenever updated
  useEffect(() => {
    try {
      localStorage.setItem('apex_photography_reviews', JSON.stringify(reviews));
    } catch (e) {
      console.warn('Failed to persist reviews', e);
    }
  }, [reviews]);

  // Track active section on scroll
  useEffect(() => {
    const handleScroll = () => {
      const reviewsEl = document.getElementById('reviews-section');
      if (reviewsEl) {
        const rect = reviewsEl.getBoundingClientRect();
        if (rect.top <= 200) {
          setActiveSection('reviews');
          return;
        }
      }
      setActiveSection('contact');
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleOpenRatingModal = () => {
    setIsRatingModalOpen(true);
  };

  const handleCloseRatingModal = () => {
    setIsRatingModalOpen(false);
  };

  const handleSubmitReview = (newReview: PhotographyRating) => {
    setReviews((prev) => [newReview, ...prev]);
    const el = document.getElementById('reviews-section');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleVoteHelpful = (reviewId: string) => {
    setReviews((prev) =>
      prev.map((r) =>
        r.id === reviewId ? { ...r, helpfulCount: r.helpfulCount + 1 } : r
      )
    );
  };

  const averageRating =
    reviews.length > 0
      ? reviews.reduce((acc, r) => acc + r.overallRating, 0) / reviews.length
      : 5.0;

  const currentCategoryName =
    PHOTOGRAPHY_CATEGORIES.find((c) => c.id === selectedCategory)?.name ||
    'Portrait & Headshots';

  return (
    <div className="min-h-screen text-[#111111] selection:bg-[#111111] selection:text-[#F6F6F4] relative font-sans">
      {/* Editorial Custom Cursor */}
      <CustomCursor />

      {/* 1. Moving Background: Paper, grain, subtle light movement, guidelines */}
      <DynamicBackground />

      {/* 2. Editorial Sticky Navbar */}
      <Navbar
        onOpenRatingModal={handleOpenRatingModal}
        activeSection={activeSection}
        reviewCount={reviews.length}
        averageRating={averageRating}
      />

      {/* 3. Main Editorial Flow */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Huge Editorial Hero with line-stagger masked reveal + asymmetrical layout + 3D art */}
        <HeroSection
          onOpenRatingModal={handleOpenRatingModal}
          reviewCount={reviews.length}
          averageRating={averageRating}
        />

        {/* Cinematic Image Element with clip-path inset reveal & parallax */}
        <CinematicImageBanner />

        {/* Editorial Contact Information + Spacious 01/02/03/04 Form + Magnetic Button */}
        <ContactSection
          onOpenRatingModal={handleOpenRatingModal}
          categoryOverride={selectedCategory}
          onCategoryChange={(cat) => setSelectedCategory(cat)}
        />

        {/* Editorial Review Slider: One review at a time + Cursor Follower + Progress Bar */}
        <ReviewsSlider
          reviews={reviews}
          onOpenRatingModal={handleOpenRatingModal}
          onVoteHelpful={handleVoteHelpful}
        />

        {/* Visual Climax: HAVE AN IDEA? LET'S TALK */}
        <FinalCTA onOpenRatingModal={handleOpenRatingModal} />
      </main>

      {/* Minimal Monochrome Integrated Footer */}
      <Footer onOpenRatingModal={handleOpenRatingModal} />

      {/* Floating Action Button Desk */}
      <DynamicActionButton
        onOpenRatingModal={handleOpenRatingModal}
        selectedCategoryName={currentCategoryName}
      />

      {/* Rate Photography Modal */}
      <RatingModal
        isOpen={isRatingModalOpen}
        onClose={handleCloseRatingModal}
        onSubmitReview={handleSubmitReview}
      />
    </div>
  );
}
