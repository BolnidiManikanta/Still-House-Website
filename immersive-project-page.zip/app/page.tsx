import type { Metadata } from "next"
import Experience from "@/components/project/experience"

export const metadata: Metadata = {
  title: "Constellation — Immersive Case Study",
  description:
    "An interactive digital-art case study: editorial typography, procedural WebGL sculpture and scroll-driven light-to-dark choreography.",
}

export default function Page() {
  return (
    <main className="relative min-h-screen overflow-clip bg-[#e8e8e8]">
      <Experience />
    </main>
  )
}
