/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { AtmosphericBackground } from './components/AtmosphericBackground';
import { CentralExhibitionShowcase } from './components/CentralExhibitionShowcase';
import { CategoryStoryView } from './components/CategoryStoryView';
import { ExhibitionHeader } from './components/ExhibitionHeader';
import { LeftChaptersControl } from './components/LeftChaptersControl';
import { ExhibitionPeripherals } from './components/ExhibitionPeripherals';
import { NavigationDrawer } from './components/NavigationDrawer';
import { Lightbox } from './components/Lightbox';
import { InquiryModal } from './components/InquiryModal';
import {
  CATEGORIES,
  PORTFOLIO_IMAGES,
  PortfolioImage,
} from './data/portfolioData';

export default function App() {
  // Navigation & View State
  const [currentView, setCurrentView] = useState<'installation' | 'story'>('installation');
  const [selectedCategoryKey, setSelectedCategoryKey] = useState<string>('wedding');
  const [hoveredCategory, setHoveredCategory] = useState<string | null>(null);

  // Menu drawer state
  const [menuOpen, setMenuOpen] = useState(false);

  // Mouse coordinate tracking for 3D spatial interaction
  const [mousePos, setMousePos] = useState<{ x: number; y: number }>({ x: 0, y: 0 });

  // Lightbox viewer state
  const [lightboxOpen, setLightboxOpen] = useState(false);
  const [activeImageIndex, setActiveImageIndex] = useState(0);

  // Studio booking inquiry state
  const [inquiryOpen, setInquiryOpen] = useState(false);
  const [inquiryCategory, setInquiryCategory] = useState<string>('WEDDING');

  // Track mouse coordinates normalized between -1 and 1
  const handleMouseMove = useCallback((e: React.MouseEvent) => {
    const x = (e.clientX / window.innerWidth - 0.5) * 2;
    const y = (e.clientY / window.innerHeight - 0.5) * 2;
    setMousePos({ x, y });
  }, []);

  // Handle URL hash on initial load and change
  useEffect(() => {
    const handleHashChange = () => {
      const hash = window.location.hash.replace('#', '').toLowerCase();
      const validCategory = CATEGORIES.find(
        (c) => c.key === hash || c.label.toLowerCase() === hash
      );

      if (validCategory) {
        setSelectedCategoryKey(validCategory.key);
        setCurrentView('story');
      } else {
        setCurrentView('installation');
      }
    };

    handleHashChange();
    window.addEventListener('hashchange', handleHashChange);
    return () => window.removeEventListener('hashchange', handleHashChange);
  }, []);

  // Select category and enter the photographic story
  const handleSelectCategory = (categoryKey: string) => {
    setSelectedCategoryKey(categoryKey);
    setCurrentView('story');
    window.history.pushState(null, '', `#${categoryKey}`);
  };

  // Return from category story back to the 3D sculpture
  const handleBackToSculpture = () => {
    setCurrentView('installation');
    window.history.pushState(null, '', '#');
  };

  // Open Lightbox
  const handleOpenLightbox = (image: PortfolioImage) => {
    const pool = PORTFOLIO_IMAGES;
    const index = pool.findIndex((item) => item.id === image.id);
    setActiveImageIndex(index !== -1 ? index : 0);
    setLightboxOpen(true);
  };

  // Open Inquiry modal
  const handleOpenInquiry = (categoryName?: string) => {
    if (categoryName) {
      setInquiryCategory(categoryName);
    } else {
      const activeCat = CATEGORIES.find((c) => c.key === selectedCategoryKey);
      setInquiryCategory(activeCat ? activeCat.label : 'WEDDING');
    }
    setInquiryOpen(true);
  };

  // Active category index (0-7)
  const currentCategoryIndex = useMemo(() => {
    const idx = CATEGORIES.findIndex((c) => c.key === (hoveredCategory || selectedCategoryKey));
    return idx !== -1 ? idx : 0;
  }, [hoveredCategory, selectedCategoryKey]);

  // Active category object
  const activeCategoryInfo = useMemo(() => {
    return (
      CATEGORIES.find((c) => c.key === selectedCategoryKey) || CATEGORIES[0]
    );
  }, [selectedCategoryKey]);

  // Images for the active category
  const activeCategoryImages = useMemo(() => {
    return PORTFOLIO_IMAGES.filter((img) => img.category === selectedCategoryKey);
  }, [selectedCategoryKey]);

  return (
    <div
      className="min-h-screen bg-[#ECE8E8] text-[#1F1F1F] overflow-x-hidden select-none font-sans"
      onMouseMove={currentView === 'installation' ? handleMouseMove : undefined}
    >
      {/* 25 Residences Inspired White-Grey Atmospheric Background */}
      <AtmosphericBackground mousePosition={mousePos} />

      {/* Exhibition Header (KRISHNA PHOTOGRAPHY | INQUIRE ↗ | Hamburger Menu) */}
      <ExhibitionHeader
        onOpenInquiry={() => handleOpenInquiry()}
        onToggleMenu={() => setMenuOpen(!menuOpen)}
        isMenuOpen={menuOpen}
        isInsideStory={currentView === 'story'}
        onBackToSculpture={handleBackToSculpture}
      />

      {/* Main Exhibition Stage */}
      <main className="relative z-10">
        {currentView === 'installation' ? (
          /* GALLERY EXHIBITION STAGE (Globe removed, clean editorial theme preserved) */
          <div className="relative w-full h-screen overflow-hidden flex items-center justify-center">
            {/* Left-Side Chapters 08 Navigation (Diagram removed, clean category list) */}
            <LeftChaptersControl
              activeCategory={selectedCategoryKey}
              onSelectCategory={handleSelectCategory}
              hoveredCategory={hoveredCategory}
              setHoveredCategory={setHoveredCategory}
            />

            {/* Central Archival Exhibition Showcase (25 Residences Style Dynamic Floating Gallery) */}
            <div className="absolute inset-0 z-10 w-full h-full pointer-events-none">
              <CentralExhibitionShowcase
                selectedCategoryKey={selectedCategoryKey}
                onSelectCategory={handleSelectCategory}
                hoveredCategory={hoveredCategory}
                onOpenLightbox={handleOpenLightbox}
                onEnterStory={handleSelectCategory}
                mousePosition={mousePos}
              />
            </div>

            {/* Editorial Links, Visual Archive Caption, and 01/08 Counter */}
            <ExhibitionPeripherals
              currentCategoryIndex={currentCategoryIndex}
              totalCategories={CATEGORIES.length}
              onNavigateSection={(sec) => {
                if (sec === 'photographs' || sec === 'stories') {
                  handleSelectCategory('wedding');
                } else if (sec === 'people') {
                  handleSelectCategory('portraits');
                } else if (sec === 'places') {
                  handleSelectCategory('pre-wedding');
                }
              }}
            />
          </div>
        ) : (
          /* CINEMATIC CATEGORY STORY EXPERIENCE */
          <div className="pt-20">
            <CategoryStoryView
              category={activeCategoryInfo}
              images={activeCategoryImages}
              onBack={handleBackToSculpture}
              onSelectCategory={handleSelectCategory}
              onImageClick={handleOpenLightbox}
              onInquire={handleOpenInquiry}
            />
          </div>
        )}
      </main>

      {/* Fullscreen Navigation Drawer (Opened via hamburger button) */}
      <NavigationDrawer
        isOpen={menuOpen}
        onClose={() => setMenuOpen(false)}
        onSelectCategory={handleSelectCategory}
        onOpenInquiry={() => handleOpenInquiry()}
      />

      {/* Full-Screen High-Resolution Lightbox */}
      <Lightbox
        images={PORTFOLIO_IMAGES}
        currentIndex={activeImageIndex}
        isOpen={lightboxOpen}
        onClose={() => setLightboxOpen(false)}
        onNavigate={(newIdx) => setActiveImageIndex(newIdx)}
        onInquireImage={(img) => handleOpenInquiry(img.categoryName.toUpperCase())}
      />

      {/* Studio Inquiry Modal */}
      <InquiryModal
        isOpen={inquiryOpen}
        onClose={() => setInquiryOpen(false)}
        defaultCategory={inquiryCategory}
      />
    </div>
  );
}
