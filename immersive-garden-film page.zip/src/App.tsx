/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { useLenisScroll } from './hooks/useLenisScroll';
import { Navigation } from './components/Navigation';
import { HeroSection } from './components/HeroSection';
import { StatementSection } from './components/StatementSection';
import { ApproachSection } from './components/ApproachSection';
import { ProjectShowcase } from './components/ProjectShowcase';
import { ProjectDirectory } from './components/ProjectDirectory';
import { MissionSection } from './components/MissionSection';
import { BlackFooter } from './components/BlackFooter';
import { ProjectModal } from './components/ProjectModal';
import { MenuOverlay } from './components/MenuOverlay';
import { CircularScrollIndicator } from './components/CircularScrollIndicator';
import { CustomCursor } from './components/CustomCursor';
import HeroBackground from './components/HeroBackground';
import { PROJECTS_DATA } from './data/projectsData';
import { Project } from './types';

export default function App() {
  const { scrollState, scrollTo } = useLenisScroll();
  const [selectedProject, setSelectedProject] = useState<Project | null>(null);
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const handleNavigate = (sectionId: string) => {
    const el = document.getElementById(sectionId);
    if (el) {
      scrollTo(el, { offset: -20, duration: 1.5 });
    }
  };

  return (
    <div className="relative min-h-screen bg-[#EDEAE4] text-[#141414] overflow-x-hidden selection:bg-black selection:text-white">
      {/* 0. Global Fixed Background System (Base, Ambient Autonomic Reveals, Cursor Reveal) */}
      <HeroBackground />

      {/* 1. Custom Minimal Cursor */}
      <CustomCursor />

      {/* 2. Top Navigation */}
      <Navigation
        scrollProgress={scrollState.progress}
        onOpenMenu={() => setIsMenuOpen(true)}
        onOpenProjects={() => handleNavigate('selected-projects')}
      />

      {/* 4. DOM Editorial Sections Layer (Transparent over #E8E8E8 relief) */}
      <main className="relative z-10 w-full flex flex-col">
        {/* Hero Viewport */}
        <HeroSection
          onSeeAllProjects={() => handleNavigate('selected-projects')}
          onScrollDown={() => handleNavigate('statement')}
        />

        {/* Statement Section */}
        <StatementSection />

        {/* Approach Section */}
        <ApproachSection />

        {/* Featured Project Showcase */}
        <ProjectShowcase
          projects={PROJECTS_DATA}
          onSelectProject={(proj) => setSelectedProject(proj)}
        />

        {/* Full Project Directory */}
        <ProjectDirectory
          projects={PROJECTS_DATA}
          onSelectProject={(proj) => setSelectedProject(proj)}
        />

        {/* Mission & Recognition */}
        <MissionSection />

        {/* The ONLY Black Section: Final Footer / End State Transition (#030303) */}
        <BlackFooter onScrollToTop={() => scrollTo(0, { duration: 1.8 })} />
      </main>

      {/* 5. Circular Scroll Indicator (Bottom Right) */}
      <CircularScrollIndicator
        progress={scrollState.progress}
        onClick={() => {
          if (scrollState.progress > 0.85) {
            scrollTo(0, { duration: 1.8 });
          } else {
            scrollTo(window.scrollY + window.innerHeight * 0.9, { duration: 1.2 });
          }
        }}
      />

      {/* 6. Case Study Detail Modal */}
      <ProjectModal
        project={selectedProject}
        onClose={() => setSelectedProject(null)}
      />

      {/* 7. Fullscreen Menu Overlay */}
      <MenuOverlay
        isOpen={isMenuOpen}
        onClose={() => setIsMenuOpen(false)}
        onNavigate={handleNavigate}
      />
    </div>
  );
}
