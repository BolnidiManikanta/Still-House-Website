import { useEffect, useState, useRef, useCallback } from 'react';
import Lenis from 'lenis';
import { ScrollState } from '../types';

export function useLenisScroll() {
  const [scrollState, setScrollState] = useState<ScrollState>({
    progress: 0,
    velocity: 0,
    direction: 1,
    scrollY: 0,
  });

  const lenisRef = useRef<Lenis | null>(null);
  const prevProgressRef = useRef<number>(0);

  useEffect(() => {
    // Initialize Lenis smooth scroll with natural physical inertia
    const lenis = new Lenis({
      duration: 1.35,
      easing: (t: number) => Math.min(1, 1.001 - Math.pow(2, -10 * t)),
      orientation: 'vertical',
      gestureOrientation: 'vertical',
      smoothWheel: true,
      wheelMultiplier: 0.9,
      touchMultiplier: 1.5,
      infinite: false,
    });

    lenisRef.current = lenis;

    function onScroll(e: { progress: number; velocity: number; direction: number; scroll: number }) {
      // Only update if difference is noticeable to save unnecessary renders
      if (Math.abs(e.progress - prevProgressRef.current) > 0.0002 || e.progress === 0 || e.progress === 1) {
        prevProgressRef.current = e.progress;
        setScrollState({
          progress: e.progress,
          velocity: e.velocity,
          direction: e.direction,
          scrollY: e.scroll,
        });
      }
    }

    lenis.on('scroll', onScroll);

    // Synchronized RAF clock
    let rafId: number;
    function raf(time: number) {
      lenis.raf(time);
      rafId = requestAnimationFrame(raf);
    }
    rafId = requestAnimationFrame(raf);

    return () => {
      cancelAnimationFrame(rafId);
      lenis.destroy();
      lenisRef.current = null;
    };
  }, []);

  const scrollTo = useCallback((target: string | number | HTMLElement, options?: { offset?: number; duration?: number }) => {
    if (lenisRef.current) {
      lenisRef.current.scrollTo(target, options);
    }
  }, []);

  return { scrollState, scrollTo };
}
