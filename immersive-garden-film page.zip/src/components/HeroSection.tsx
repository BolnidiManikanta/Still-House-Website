import React from 'react';
interface HeroSectionProps {
  onSeeAllProjects: () => void;
  onScrollDown: () => void;
}

export const HeroSection: React.FC<HeroSectionProps> = ({
  onSeeAllProjects,
  onScrollDown,
}) => {
  return (
    <section
      id="hero"
      className="relative w-full h-screen min-h-[640px] flex flex-col justify-between px-6 sm:px-12 md:px-16 pt-24 pb-10 pointer-events-none"
    >
      {/* Top micro-meta */}
      <div className="relative z-20 flex justify-between items-start w-full pt-2 pointer-events-auto">
        <div className="flex flex-col">
          <span className="text-[10px] tracking-[0.3em] font-semibold text-[#555048] uppercase mb-1">
            Architectural Reliefs
          </span>
          <p className="text-[10px] uppercase tracking-[0.26em] text-[#3A352E] font-medium">
            Creative Direction & WebGL
          </p>
        </div>

        <button
          id="hero-about-link"
          onClick={onSeeAllProjects}
          className="group flex items-center gap-2.5 px-4 py-1.5 rounded-full relief-pill text-[10px] uppercase tracking-[0.24em] font-semibold text-[#2A251E] hover:text-black transition-all border border-black/15 hover:border-black/30 cursor-pointer"
        >
          <span className="w-1.5 h-1.5 rounded-full bg-[#1A1A1A] group-hover:scale-150 transition-transform" />
          <span>Selected Works (06)</span>
        </button>
      </div>

      {/* Main Center Editorial Composition */}
      <div className="relative z-20 w-full my-auto py-2 flex flex-col items-center justify-center text-center pointer-events-auto px-4">
        {/* Editorial Subtitle with delicate flanking hairline lines */}
        <div className="flex items-center gap-3 mb-2.5 sm:mb-3">
          <div className="w-8 sm:w-10 h-px bg-[#4E483E]/30" />
          <p className="text-[12px] sm:text-[13px] md:text-[14px] italic font-serif-luxury text-[#4E483E] tracking-wide">
            The tactile nature of absence &amp; spatial light.
          </p>
          <div className="w-8 sm:w-10 h-px bg-[#4E483E]/30" />
        </div>

        {/* Small pill badge positioned with clean separation above headline */}
        <div className="inline-flex items-center gap-2 px-4 py-1.5 mb-4 sm:mb-5 rounded-full relief-pill border border-black/15 text-[10px] uppercase tracking-[0.28em] font-semibold text-[#2E2922] bg-[#EDEAE4]/80 backdrop-blur-xs">
          <span className="text-[12px] text-[#1A1A1A] leading-none">✳</span>
          <span>Continuous Bas-Relief Experience</span>
        </div>

        {/* Center Hero Headline */}
        <h1
          id="hero-main-title"
          className="font-serif-headline text-4xl sm:text-6xl md:text-7xl lg:text-[78px] xl:text-[84px] tracking-tight text-[#141414] font-normal leading-[0.98] sm:leading-[1.02] max-w-[780px] mx-auto select-none"
          style={{
            position: 'relative',
            zIndex: 30,
            color: '#141414',
            fontFamily: "'Playfair Display', 'Newsreader', 'Cormorant Garamond', Georgia, serif",
            fontWeight: 400,
            display: 'block',
            visibility: 'visible',
            opacity: 1,
          }}
        >
          <span className="block">Innovative digital</span>
          <span className="block">experiences studio</span>
        </h1>

        {/* See all projects link */}
        <button
          id="hero-see-all-btn"
          onClick={onSeeAllProjects}
          className="mt-6 sm:mt-7 text-[11px] sm:text-[12px] uppercase tracking-[0.22em] font-medium text-[#222222] hover:text-black transition-colors flex items-center gap-1.5 group cursor-pointer"
          style={{
            position: 'relative',
            zIndex: 30,
          }}
        >
          <span>See all projects</span>
          <span className="transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5">↗</span>
        </button>
      </div>

      {/* Bottom Row / Transition Zone */}
      <div className="relative z-20 w-full flex justify-between items-end pointer-events-auto pt-2">
        <div className="flex flex-col items-start gap-0.5">
          <span className="text-[9px] uppercase tracking-[0.24em] text-[#4A453E] font-medium">
            © IMMERSIVE GARDEN
          </span>
          <span className="text-[9px] uppercase tracking-[0.24em] text-[#6A655E] font-normal">
            ALL RIGHTS RESERVED
          </span>
        </div>

        {/* Scroll down indicator with fine vertical line and dot */}
        <div className="hidden sm:flex flex-col items-center gap-1.5 pr-20 md:pr-24">
          <span className="text-[10px] tracking-[0.2em] font-medium text-[#4A453E]">
            Scroll down
          </span>
          <div className="w-px h-8 bg-[#333333]/40" />
          <span className="w-1 h-1 rounded-full bg-[#333333]" />
        </div>
      </div>
    </section>
  );
};
