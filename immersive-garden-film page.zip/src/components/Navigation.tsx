import React, { useState } from 'react';
import { Volume2, VolumeX, Menu } from 'lucide-react';
import { soundscape } from '../utils/audioSynthesizer';

interface NavigationProps {
  onOpenMenu: () => void;
  onOpenProjects: () => void;
  scrollProgress: number;
}

export const Navigation: React.FC<NavigationProps> = ({
  onOpenMenu,
  onOpenProjects,
}) => {
  const [isAudioActive, setIsAudioActive] = useState(false);

  const handleToggleAudio = () => {
    const active = soundscape.toggle();
    setIsAudioActive(active);
  };

  return (
    <header
      id="main-navigation-header"
      className="fixed top-0 left-0 w-full z-40 px-6 sm:px-10 py-5 sm:py-7 flex items-center justify-between text-[#181818]"
    >
      {/* Brand Logo */}
      <div className="flex items-center gap-3">
        <a
          id="nav-brand-link"
          href="#hero"
          className="group flex items-center gap-2.5 font-display-cinzel tracking-[0.24em] text-xs sm:text-[13px] font-semibold uppercase hover:opacity-75 transition-opacity"
        >
          <div className="w-5 h-5 rounded flex items-center justify-center border border-black/30 text-[11px] font-serif font-bold text-[#1A1A1A]">
            U
          </div>
          <span className="tracking-widest text-[#1A1A1A] font-semibold">IMMERSIVE GARDEN</span>
        </a>
        <span className="hidden sm:inline-flex items-center text-[9px] uppercase tracking-[0.26em] font-semibold px-3 py-1 rounded-full relief-pill border border-black/15 text-[#3A352E]">
          STUDIO RELIEF
        </span>
      </div>

      {/* Center Studio Cities */}
      <div className="hidden lg:flex items-center gap-3 text-[10px] uppercase tracking-[0.32em] font-semibold text-[#3A352E]">
        <span>PARIS</span>
        <span className="text-[#88837A]">•</span>
        <span>TOKYO</span>
        <span className="text-[#88837A]">•</span>
        <span>NEW YORK</span>
      </div>

      {/* Right Controls */}
      <div className="flex items-center gap-4 sm:gap-6">
        {/* Sound Toggle */}
        <button
          id="sound-toggle-btn"
          onClick={handleToggleAudio}
          className={`flex items-center gap-2 text-[10px] uppercase tracking-[0.24em] font-semibold py-1.5 px-4 rounded-full relief-pill border border-black/15 text-[#2E2922] transition-all`}
          title="Toggle Ambient Acoustic Experience"
        >
          {isAudioActive ? <Volume2 className="w-3.5 h-3.5 text-[#111111]" /> : <VolumeX className="w-3.5 h-3.5 text-[#111111]" />}
          <span className="inline">{isAudioActive ? 'SOUND ON' : 'SOUND OFF'}</span>
        </button>

        {/* Projects Quick Jump */}
        <button
          id="nav-projects-trigger"
          onClick={onOpenProjects}
          className="hidden sm:inline-block text-[11px] uppercase tracking-[0.26em] font-semibold text-[#1A1A1A] hover:text-black transition-colors border-b border-[#1A1A1A] pb-0.5"
        >
          PORTFOLIO
        </button>

        {/* Menu Button */}
        <button
          id="nav-menu-btn"
          onClick={onOpenMenu}
          className="flex items-center gap-2 text-[10px] uppercase tracking-[0.26em] font-bold py-1.5 px-4 rounded-full relief-pill border border-black/15 text-[#1A1A1A] hover:text-black transition-all"
        >
          <Menu className="w-3.5 h-3.5" />
          <span>INDEX</span>
        </button>
      </div>
    </header>
  );
};
