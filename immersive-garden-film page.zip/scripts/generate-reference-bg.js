import sharp from 'sharp';
import fs from 'fs';
import path from 'path';

// Generate a pristine high-resolution photographic plaster bas-relief background
const width = 1920;
const height = 1080;

const svgContent = `
<svg width="${width}" height="${height}" viewBox="0 0 ${width} ${height}" xmlns="http://www.w3.org/2000/svg">
  <defs>
    <!-- Soft diffuse gallery directional lighting gradient -->
    <radialGradient id="galleryWall" cx="35%" cy="15%" r="85%">
      <stop offset="0%" stop-color="#F5F1EB" />
      <stop offset="35%" stop-color="#EFEBE4" />
      <stop offset="70%" stop-color="#E9E4DC" />
      <stop offset="100%" stop-color="#E2DDD4" />
    </radialGradient>

    <!-- Plaster lit from top-left (Soft ceramic highlight) -->
    <linearGradient id="plasterBevel" x1="0%" y1="0%" x2="40%" y2="100%">
      <stop offset="0%" stop-color="#FFFFFF" stop-opacity="0.9" />
      <stop offset="25%" stop-color="#F7F3EC" />
      <stop offset="75%" stop-color="#ECE7DE" />
      <stop offset="100%" stop-color="#DFD8CE" />
    </linearGradient>

    <linearGradient id="plasterTopLight" x1="0%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%" stop-color="#FAF7F2" />
      <stop offset="40%" stop-color="#F2EDE5" />
      <stop offset="100%" stop-color="#DFD8CE" />
    </linearGradient>

    <linearGradient id="plasterShade" x1="0%" y1="0%" x2="100%" y2="0%">
      <stop offset="0%" stop-color="#FAF7F2" />
      <stop offset="60%" stop-color="#ECE7DF" />
      <stop offset="100%" stop-color="#D7CFBE" />
    </linearGradient>

    <linearGradient id="barrelHori" x1="0%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%" stop-color="#FAF7F2" />
      <stop offset="20%" stop-color="#F4EFEB" />
      <stop offset="60%" stop-color="#ECE7DF" />
      <stop offset="85%" stop-color="#E1DACF" />
      <stop offset="100%" stop-color="#D2C9BB" />
    </linearGradient>

    <linearGradient id="barrelVert" x1="0%" y1="0%" x2="100%" y2="0%">
      <stop offset="0%" stop-color="#FAF7F2" />
      <stop offset="20%" stop-color="#F4EFEB" />
      <stop offset="60%" stop-color="#ECE7DF" />
      <stop offset="85%" stop-color="#E1DACF" />
      <stop offset="100%" stop-color="#D2C9BB" />
    </linearGradient>

    <radialGradient id="opticCavity" cx="40%" cy="40%" r="60%">
      <stop offset="0%" stop-color="#E8E2D8" />
      <stop offset="50%" stop-color="#D5CDC0" />
      <stop offset="80%" stop-color="#BEB5A5" />
      <stop offset="100%" stop-color="#A89E8D" />
    </radialGradient>

    <!-- Soft directional contact drop shadows -->
    <filter id="deepDropShadow" x="-30%" y="-30%" width="160%" height="180%">
      <feDropShadow dx="8" dy="24" stdDeviation="16" flood-color="#5A5245" flood-opacity="0.22" />
      <feDropShadow dx="3" dy="8" stdDeviation="5" flood-color="#463F33" flood-opacity="0.28" />
      <feDropShadow dx="1" dy="2" stdDeviation="1.5" flood-color="#2D271E" flood-opacity="0.32" />
    </filter>

    <filter id="shelfDropShadow" x="-20%" y="-20%" width="140%" height="220%">
      <feDropShadow dx="4" dy="16" stdDeviation="10" flood-color="#5A5245" flood-opacity="0.24" />
      <feDropShadow dx="1.5" dy="4" stdDeviation="3" flood-color="#3C352A" flood-opacity="0.28" />
    </filter>

    <filter id="plaqueShadow" x="-10%" y="-10%" width="120%" height="130%">
      <feDropShadow dx="2" dy="5" stdDeviation="4" flood-color="#6B6254" flood-opacity="0.18" />
    </filter>

    <filter id="softGlow" x="-10%" y="-10%" width="120%" height="120%">
      <feDropShadow dx="-1" dy="-1" stdDeviation="1" flood-color="#FFFFFF" flood-opacity="0.8" />
    </filter>
  </defs>

  <!-- Base Wall Plane -->
  <rect width="${width}" height="${height}" fill="url(#galleryWall)" />

  <!-- Architectural Wall Panel Seams (Micro-Grooves) -->
  <g stroke="#C2B9AA" stroke-width="1.2" opacity="0.65">
    <line x1="280" y1="0" x2="280" y2="340" />
    <line x1="280" y1="340" x2="630" y2="340" />
    <line x1="630" y1="0" x2="630" y2="1080" />
    <line x1="1180" y1="0" x2="1180" y2="340" />
    <line x1="1180" y1="340" x2="1920" y2="340" />
    <line x1="1520" y1="200" x2="1520" y2="1080" />

    <!-- Fluted micro-grooves (Top Right Wall) -->
    <g stroke="#B8AF9F" stroke-width="1" opacity="0.8">
      <line x1="1680" y1="210" x2="1680" y2="520" />
      <line x1="1688" y1="210" x2="1688" y2="520" />
      <line x1="1696" y1="210" x2="1696" y2="520" />
      <line x1="1704" y1="210" x2="1704" y2="520" />
      <line x1="1712" y1="210" x2="1712" y2="520" />
    </g>

    <!-- Fluted micro-grooves (Bottom Right Center Wall) -->
    <g stroke="#B8AF9F" stroke-width="1" opacity="0.8">
      <line x1="1180" y1="760" x2="1180" y2="1000" />
      <line x1="1188" y1="760" x2="1188" y2="1000" />
      <line x1="1196" y1="760" x2="1196" y2="1000" />
      <line x1="1204" y1="760" x2="1204" y2="1000" />
      <line x1="1212" y1="760" x2="1212" y2="1000" />
    </g>
  </g>

  <!-- Engraved Geometric Wall Arcs (Subtle Fine Etchings) -->
  <g fill="none" stroke="#B8AE9D" stroke-width="1.3" opacity="0.6">
    <!-- Left Gimbal Arcs -->
    <path d="M 210,380 A 180,180 0 0,0 60,630" />
    <path d="M 210,320 A 250,250 0 0,0 40,680" />
    <circle cx="210" cy="570" r="140" stroke-dasharray="2 6" stroke-width="1" />

    <!-- Mirrorless Camera Upper Left Arc -->
    <path d="M 370,140 A 170,170 0 0,1 420,380" />

    <!-- Lower Right DSLR Circular Arcs -->
    <path d="M 1240,1040 A 260,260 0 0,1 1520,770" />
    <path d="M 1750,560 A 180,180 0 0,1 1870,820" />
  </g>

  <!-- ========================================================================= -->
  <!-- 1. TOP-LEFT: Prime Lens Upright on Shelf -->
  <!-- ========================================================================= -->
  <g transform="translate(510, 150)">
    <g filter="url(#shelfDropShadow)">
      <rect x="-38" y="55" width="76" height="9" rx="2" fill="url(#plasterTopLight)" />
      <rect x="-38" y="55" width="76" height="1.5" fill="#FFFFFF" opacity="0.7" />
    </g>
    <g filter="url(#deepDropShadow)">
      <!-- Mount Collar -->
      <rect x="-26" y="42" width="52" height="13" rx="2" fill="url(#plasterBevel)" />
      <!-- Barrel -->
      <rect x="-31" y="-18" width="62" height="60" rx="3" fill="url(#barrelVert)" />
      <!-- Ribbed Focus Ring -->
      <rect x="-33" y="-6" width="66" height="26" rx="2" fill="url(#plasterTopLight)" />
      <line x1="-33" y1="0" x2="33" y2="0" stroke="#C8C0B2" stroke-width="1.2" />
      <line x1="-33" y1="7" x2="33" y2="7" stroke="#C8C0B2" stroke-width="1.2" />
      <line x1="-33" y1="14" x2="33" y2="14" stroke="#C8C0B2" stroke-width="1.2" />
      <!-- Top Front Element Rim -->
      <ellipse cx="0" cy="-18" rx="31" ry="9" fill="url(#plasterBevel)" stroke="#FAF7F2" stroke-width="1" />
      <ellipse cx="0" cy="-18" rx="24" ry="7" fill="url(#opticCavity)" />
      <ellipse cx="0" cy="-18" rx="14" ry="4" fill="#9E9484" />
    </g>
  </g>

  <!-- ========================================================================= -->
  <!-- 2. UPPER-LEFT: Mirrorless Camera with Prime Lens on Shelf & Plaque -->
  <!-- ========================================================================= -->
  <g transform="translate(350, 330)">
    <rect x="-100" y="-65" width="200" height="135" rx="4" fill="#E8E2D8" filter="url(#plaqueShadow)" stroke="#D8D0C2" stroke-width="1" />
    <g filter="url(#shelfDropShadow)">
      <rect x="-100" y="70" width="200" height="11" rx="2" fill="url(#plasterTopLight)" />
      <rect x="-100" y="70" width="200" height="2" fill="#FFFFFF" opacity="0.8" />
    </g>
    <g filter="url(#deepDropShadow)">
      <!-- Camera Main Chassis -->
      <rect x="-75" y="-35" width="150" height="105" rx="8" fill="url(#plasterBevel)" stroke="#FAF7F2" stroke-width="1" />
      <!-- Handgrip Extrusion -->
      <path d="M -75,-20 Q -92,-10 -92,40 Q -92,62 -75,68 Z" fill="url(#plasterShade)" />
      <!-- Viewfinder Pentaprism -->
      <polygon points="-26,-35 0,-56 26,-35" fill="url(#plasterTopLight)" stroke="#FAF7F2" stroke-width="1" />
      <!-- Top Dials & Shutter -->
      <rect x="-68" y="-43" width="18" height="8" rx="2" fill="url(#plasterTopLight)" />
      <rect x="42" y="-43" width="24" height="7" rx="2" fill="url(#plasterTopLight)" />
      <!-- Forward Large Lens Barrel -->
      <rect x="-42" y="-12" width="84" height="78" rx="42" fill="url(#barrelVert)" />
      <circle cx="0" cy="27" r="42" fill="url(#plasterBevel)" stroke="#FAF7F2" stroke-width="2" />
      <circle cx="0" cy="27" r="33" fill="url(#opticCavity)" />
      <circle cx="0" cy="27" r="20" fill="#9E9484" />
      <circle cx="0" cy="27" r="11" fill="#7E7566" />
      <!-- Knurled focus ring marks -->
      <circle cx="0" cy="27" r="42" stroke="#CCC3B4" stroke-width="3" stroke-dasharray="3 4" fill="none" />
    </g>
  </g>

  <!-- ========================================================================= -->
  <!-- 3. MID-LEFT: 3-Axis Motorized Gimbal Stabilizer on Open Tripod -->
  <!-- ========================================================================= -->
  <g transform="translate(200, 620)">
    <g filter="url(#deepDropShadow)">
      <!-- Tripod Base Feet -->
      <line x1="-38" y1="165" x2="0" y2="140" stroke="url(#plasterTopLight)" stroke-width="9" stroke-linecap="round" />
      <line x1="38" y1="165" x2="0" y2="140" stroke="url(#plasterTopLight)" stroke-width="9" stroke-linecap="round" />
      <line x1="0" y1="170" x2="0" y2="140" stroke="url(#plasterTopLight)" stroke-width="9" stroke-linecap="round" />
      <!-- Handle -->
      <rect x="-10" y="45" width="20" height="95" rx="6" fill="url(#barrelVert)" />
      <rect x="-12" y="65" width="24" height="38" rx="3" fill="url(#plasterTopLight)" />
      <circle cx="0" cy="80" r="5" fill="#CCC3B4" />
      <!-- Pan Motor -->
      <circle cx="0" cy="38" r="15" fill="url(#plasterBevel)" stroke="#FAF7F2" stroke-width="1.5" />
      <!-- Curved Mechanical Gimbal Arm -->
      <path d="M 0,38 Q -42,36 -42,-12 Q -42,-44 0,-44" fill="none" stroke="url(#plasterBevel)" stroke-width="13" stroke-linecap="round" />
      <!-- Roll & Tilt Motors -->
      <circle cx="-42" cy="-12" r="14" fill="url(#plasterBevel)" />
      <circle cx="30" cy="-12" r="14" fill="url(#plasterBevel)" />
      <rect x="-10" y="-32" width="58" height="40" rx="5" fill="url(#plasterBevel)" />
      <!-- Mounted Camera Body -->
      <rect x="-6" y="-26" width="48" height="32" rx="4" fill="#FAF7F2" />
      <circle cx="18" cy="-10" r="16" fill="url(#plasterBevel)" stroke="#FAF7F2" stroke-width="1.5" />
      <circle cx="18" cy="-10" r="11" fill="url(#opticCavity)" />
    </g>
  </g>

  <!-- ========================================================================= -->
  <!-- 4. FAR-LEFT BOTTOM: Tiny Prime Lens on Mini Shelf -->
  <!-- ========================================================================= -->
  <g transform="translate(60, 700)">
    <g filter="url(#shelfDropShadow)">
      <rect x="-26" y="24" width="52" height="7" rx="2" fill="url(#plasterTopLight)" />
    </g>
    <g filter="url(#deepDropShadow)">
      <rect x="-17" y="-18" width="34" height="42" rx="3" fill="url(#barrelVert)" />
      <ellipse cx="0" cy="-18" rx="17" ry="5.5" fill="url(#plasterBevel)" />
      <ellipse cx="0" cy="-18" rx="12" ry="4" fill="url(#opticCavity)" />
    </g>
  </g>

  <!-- ========================================================================= -->
  <!-- 5. BOTTOM-LEFT: Horizontal 70-200mm Telephoto Lens on Shelf & Plaque -->
  <!-- ========================================================================= -->
  <g transform="translate(440, 880)">
    <rect x="-130" y="-35" width="260" height="105" rx="4" fill="#E8E2D8" filter="url(#plaqueShadow)" stroke="#D8D0C2" stroke-width="1" />
    <g filter="url(#shelfDropShadow)">
      <rect x="-130" y="60" width="260" height="13" rx="2" fill="url(#plasterTopLight)" />
      <rect x="-130" y="60" width="260" height="2.5" fill="#FFFFFF" opacity="0.8" />
    </g>
    <g filter="url(#deepDropShadow)">
      <!-- Right Lens Mount End -->
      <rect x="80" y="-14" width="24" height="58" rx="4" fill="url(#plasterBevel)" />
      <!-- Main Barrel -->
      <rect x="-85" y="-24" width="165" height="78" rx="6" fill="url(#barrelHori)" />
      <!-- Stepped Front Flange & Hood Flare -->
      <rect x="-115" y="-30" width="38" height="90" rx="6" fill="url(#plasterBevel)" />
      <path d="M -115,-30 L -128,-33 L -128,63 L -115,60 Z" fill="url(#plasterBevel)" />
      <!-- Tactile Focus & Zoom Rings -->
      <rect x="-70" y="-27" width="40" height="84" rx="3" fill="url(#plasterTopLight)" />
      <rect x="18" y="-27" width="48" height="84" rx="3" fill="url(#plasterTopLight)" />
      <line x1="-54" y1="-27" x2="-54" y2="57" stroke="#CCC3B4" stroke-width="1.5" />
      <line x1="42" y1="-27" x2="42" y2="57" stroke="#CCC3B4" stroke-width="1.5" />
      <!-- Tripod Collar & Stand Foot -->
      <rect x="-12" y="-29" width="22" height="88" rx="3" fill="url(#plasterTopLight)" />
      <rect x="-7" y="52" width="14" height="20" rx="2" fill="url(#plasterBevel)" />
      <rect x="-18" y="68" width="36" height="9" rx="2" fill="url(#plasterBevel)" />
      <!-- Inset Distance Window -->
      <rect x="-4" y="-20" width="20" height="9" rx="1.5" fill="#CCC3B4" />
    </g>
  </g>

  <!-- ========================================================================= -->
  <!-- 6. TOP CENTER-LEFT: Vintage Compact Rangefinder Camera on Shelf -->
  <!-- ========================================================================= -->
  <g transform="translate(790, 235)">
    <g filter="url(#shelfDropShadow)">
      <rect x="-85" y="42" width="170" height="10" rx="2" fill="url(#plasterTopLight)" />
      <rect x="-85" y="42" width="170" height="2" fill="#FFFFFF" opacity="0.8" />
    </g>
    <g filter="url(#deepDropShadow)">
      <!-- Main Chassis -->
      <rect x="-70" y="-32" width="140" height="74" rx="7" fill="url(#plasterBevel)" stroke="#FAF7F2" stroke-width="1" />
      <rect x="-70" y="-39" width="140" height="9" rx="3" fill="#FAF7F2" />
      <!-- Shutter & Dials -->
      <rect x="45" y="-45" width="15" height="7" rx="2" fill="#FAF7F2" />
      <rect x="24" y="-44" width="18" height="6" rx="2" fill="#FAF7F2" />
      <!-- Viewfinder Windows -->
      <rect x="-56" y="-26" width="16" height="11" rx="2" fill="#CCC3B4" />
      <rect x="40" y="-26" width="20" height="13" rx="2" fill="#CCC3B4" />
      <circle cx="16" cy="-20" r="4.5" fill="#CCC3B4" />
      <!-- Center Prime Lens -->
      <circle cx="14" cy="6" r="30" fill="url(#plasterBevel)" stroke="#FAF7F2" stroke-width="2" />
      <circle cx="14" cy="6" r="23" fill="url(#opticCavity)" />
      <circle cx="14" cy="6" r="14" fill="#9E9484" />
      <circle cx="14" cy="6" r="7" fill="#7E7566" />
    </g>
  </g>

  <!-- ========================================================================= -->
  <!-- 7. TOP CENTER-RIGHT: Action Cube Camera on Mini Shelf -->
  <!-- ========================================================================= -->
  <g transform="translate(1125, 180)">
    <g filter="url(#shelfDropShadow)">
      <rect x="-30" y="24" width="60" height="7.5" rx="2" fill="url(#plasterTopLight)" />
    </g>
    <g filter="url(#deepDropShadow)">
      <rect x="-24" y="-22" width="48" height="46" rx="7" fill="url(#plasterBevel)" stroke="#FAF7F2" stroke-width="1" />
      <circle cx="0" cy="1" r="15" fill="url(#plasterBevel)" stroke="#FAF7F2" stroke-width="1.5" />
      <circle cx="0" cy="1" r="11" fill="url(#opticCavity)" />
      <rect x="-15" y="-26" width="12" height="4.5" rx="1.5" fill="#FAF7F2" />
    </g>
  </g>

  <!-- ========================================================================= -->
  <!-- 8. LOWER CENTER-LEFT (UPPER): Compact Rangefinder on Shelf -->
  <!-- ========================================================================= -->
  <g transform="translate(550, 585)">
    <g filter="url(#shelfDropShadow)">
      <rect x="-45" y="26" width="90" height="8" rx="2" fill="url(#plasterTopLight)" />
    </g>
    <g filter="url(#deepDropShadow)">
      <rect x="-38" y="-20" width="76" height="46" rx="6" fill="url(#plasterBevel)" />
      <circle cx="6" cy="3" r="17" fill="url(#plasterBevel)" stroke="#FAF7F2" stroke-width="1.5" />
      <circle cx="6" cy="3" r="12" fill="url(#opticCavity)" />
    </g>
  </g>

  <!-- ========================================================================= -->
  <!-- 9. LOWER CENTER-LEFT (LOWER): Medium Format Hasselblad Box on Square Plaque -->
  <!-- ========================================================================= -->
  <g transform="translate(420, 715)">
    <rect x="-60" y="-60" width="120" height="120" rx="4" fill="#E8E2D8" filter="url(#plaqueShadow)" stroke="#D8D0C2" stroke-width="1" />
    <g filter="url(#deepDropShadow)">
      <rect x="-45" y="-45" width="90" height="90" rx="9" fill="url(#plasterBevel)" stroke="#FAF7F2" stroke-width="1" />
      <!-- Side Film Crank -->
      <circle cx="45" cy="-5" r="12" fill="url(#plasterBevel)" />
      <!-- Front Carl Zeiss Lens -->
      <circle cx="0" cy="0" r="30" fill="url(#plasterBevel)" stroke="#FAF7F2" stroke-width="2" />
      <circle cx="0" cy="0" r="23" fill="url(#opticCavity)" />
      <circle cx="0" cy="0" r="13" fill="#9E9484" />
      <!-- Waist Level Finder Hood -->
      <rect x="-26" y="-54" width="52" height="9" rx="2" fill="#FAF7F2" />
    </g>
  </g>

  <!-- ========================================================================= -->
  <!-- 10. BOTTOM CENTER-LEFT: Small Rangefinder Body on Shelf -->
  <!-- ========================================================================= -->
  <g transform="translate(645, 765)">
    <g filter="url(#shelfDropShadow)">
      <rect x="-58" y="24" width="116" height="8" rx="2" fill="url(#plasterTopLight)" />
    </g>
    <g filter="url(#deepDropShadow)">
      <rect x="-50" y="-20" width="100" height="44" rx="6" fill="url(#plasterBevel)" />
      <circle cx="8" cy="2" r="18" fill="url(#plasterBevel)" stroke="#FAF7F2" stroke-width="1.5" />
      <circle cx="8" cy="2" r="12" fill="url(#opticCavity)" />
    </g>
  </g>

  <!-- ========================================================================= -->
  <!-- 11. BOTTOM CENTER: Large Modular Cinema Rig & Upright Lens on Shelf -->
  <!-- ========================================================================= -->
  <g transform="translate(980, 855)">
    <g filter="url(#shelfDropShadow)">
      <rect x="-150" y="75" width="300" height="13" rx="2" fill="url(#plasterTopLight)" />
      <rect x="-150" y="75" width="300" height="2.5" fill="#FFFFFF" opacity="0.8" />
    </g>
    <g filter="url(#deepDropShadow)">
      <!-- Cinema Camera Brain -->
      <rect x="-75" y="-50" width="150" height="125" rx="9" fill="url(#plasterBevel)" stroke="#FAF7F2" stroke-width="1" />
      <!-- Top Handle Rigging -->
      <path d="M -54,-50 L -54,-82 L 65,-82 L 65,-50" fill="none" stroke="url(#plasterBevel)" stroke-width="15" stroke-linecap="round" stroke-linejoin="round" />
      <rect x="-44" y="-87" width="98" height="11" rx="3" fill="#FAF7F2" />
      <!-- Side Cooling Slots -->
      <rect x="16" y="-28" width="48" height="76" rx="4" fill="#E8E2D8" stroke="#DDD6CB" stroke-width="1" />
      <line x1="24" y1="-14" x2="56" y2="-14" stroke="#CCC3B4" stroke-width="2.2" />
      <line x1="24" y1="1" x2="56" y2="1" stroke="#CCC3B4" stroke-width="2.2" />
      <line x1="24" y1="16" x2="56" y2="16" stroke="#CCC3B4" stroke-width="2.2" />
      <line x1="24" y1="31" x2="56" y2="31" stroke="#CCC3B4" stroke-width="2.2" />
      <!-- Anamorphic Cinema Front Lens / Matte Box -->
      <g transform="translate(-92, 14)">
        <rect x="-38" y="-38" width="55" height="76" rx="7" fill="url(#barrelVert)" />
        <ellipse cx="-38" cy="0" rx="16" ry="38" fill="url(#plasterBevel)" stroke="#FAF7F2" stroke-width="1.8" />
        <ellipse cx="-38" cy="0" rx="11" ry="29" fill="url(#opticCavity)" />
      </g>
      <!-- Base Rails -->
      <circle cx="-38" cy="68" r="6" fill="#FAF7F2" />
      <circle cx="38" cy="68" r="6" fill="#FAF7F2" />
    </g>
    <!-- Right Companion Prime Lens on Same Shelf -->
    <g transform="translate(155, 30)" filter="url(#deepDropShadow)">
      <rect x="-19" y="-32" width="38" height="48" rx="3" fill="url(#barrelVert)" />
      <ellipse cx="0" cy="-32" rx="19" ry="6.5" fill="url(#plasterBevel)" />
      <ellipse cx="0" cy="-32" rx="13" ry="4.5" fill="url(#opticCavity)" />
    </g>
  </g>

  <!-- ========================================================================= -->
  <!-- 12. TOP RIGHT: Large Production Cinema Rig with Matte Box & EVF -->
  <!-- ========================================================================= -->
  <g transform="translate(1380, 220)">
    <g filter="url(#shelfDropShadow)">
      <rect x="-170" y="70" width="230" height="13" rx="2" fill="url(#plasterTopLight)" />
      <rect x="-170" y="70" width="230" height="2.5" fill="#FFFFFF" opacity="0.8" />
    </g>
    <g filter="url(#deepDropShadow)">
      <!-- Camera Brain Chassis -->
      <rect x="-65" y="-60" width="150" height="130" rx="10" fill="url(#plasterBevel)" stroke="#FAF7F2" stroke-width="1" />
      <!-- Perforated Top Handle Rigging -->
      <path d="M -44,-60 L -44,-98 L 70,-98 L 70,-60" fill="none" stroke="url(#plasterBevel)" stroke-width="16" stroke-linecap="round" stroke-linejoin="round" />
      <!-- Side Controls & Media Bay -->
      <rect x="16" y="-38" width="60" height="92" rx="5" fill="#E8E2D8" stroke="#DDD6CB" stroke-width="1" />
      <rect x="24" y="-28" width="44" height="26" rx="2" fill="#D8D0C2" />
      <circle cx="35" cy="18" r="6.5" fill="#CCC3B4" />
      <circle cx="55" cy="18" r="4.5" fill="#CCC3B4" />
      <circle cx="35" cy="34" r="4.5" fill="#CCC3B4" />
      <!-- Large Matte Box & Cinema Prime Lens -->
      <g transform="translate(-115, 12)">
        <rect x="-38" y="-42" width="55" height="84" rx="7" fill="url(#barrelVert)" />
        <path d="M -38,-42 L -68,-54 L -68,54 L -38,42 Z" fill="url(#plasterBevel)" />
        <ellipse cx="-68" cy="0" rx="14" ry="52" fill="url(#plasterBevel)" stroke="#FAF7F2" stroke-width="2" />
        <ellipse cx="-68" cy="0" rx="9.5" ry="41" fill="url(#opticCavity)" />
      </g>
      <!-- 15mm Base Support Rods -->
      <circle cx="-38" cy="64" r="6.5" fill="#FAF7F2" />
      <circle cx="38" cy="64" r="6.5" fill="#FAF7F2" />
    </g>
    <!-- Separate Upright Lens to the Right -->
    <g transform="translate(135, 120)">
      <g filter="url(#shelfDropShadow)">
        <rect x="-32" y="42" width="64" height="8" rx="2" fill="url(#plasterTopLight)" />
      </g>
      <g filter="url(#deepDropShadow)">
        <rect x="-18" y="0" width="36" height="42" rx="3" fill="url(#barrelVert)" />
        <ellipse cx="0" cy="0" rx="18" ry="6" fill="url(#plasterBevel)" />
        <ellipse cx="0" cy="0" rx="12" ry="4" fill="url(#opticCavity)" />
      </g>
    </g>
  </g>

  <!-- ========================================================================= -->
  <!-- 13. MIDDLE-RIGHT: Horizontal 70-200mm Telephoto Lens on Shelf -->
  <!-- ========================================================================= -->
  <g transform="translate(1550, 495)">
    <g filter="url(#shelfDropShadow)">
      <rect x="-110" y="34" width="150" height="11" rx="2" fill="url(#plasterTopLight)" />
      <rect x="-110" y="34" width="150" height="2.5" fill="#FFFFFF" opacity="0.8" />
    </g>
    <g filter="url(#deepDropShadow)">
      <rect x="-92" y="-24" width="125" height="58" rx="5" fill="url(#barrelHori)" />
      <rect x="-110" y="-28" width="24" height="66" rx="4" fill="url(#plasterBevel)" />
      <rect x="-76" y="-26" width="34" height="62" rx="2" fill="url(#plasterTopLight)" />
      <rect x="4" y="-26" width="28" height="62" rx="2" fill="url(#plasterTopLight)" />
      <rect x="-26" y="26" width="20" height="11" rx="2" fill="url(#plasterTopLight)" />
    </g>
  </g>

  <!-- ========================================================================= -->
  <!-- 14. LOWER MIDDLE-RIGHT: Mirrorless Camera Body on Plaque -->
  <!-- ========================================================================= -->
  <g transform="translate(1380, 650)">
    <rect x="-60" y="-50" width="120" height="100" rx="3.5" fill="#E8E2D8" filter="url(#plaqueShadow)" stroke="#D8D0C2" stroke-width="1" />
    <g filter="url(#deepDropShadow)">
      <rect x="-46" y="-33" width="92" height="66" rx="7" fill="url(#plasterBevel)" stroke="#FAF7F2" stroke-width="1" />
      <polygon points="-16,-33 0,-46 16,-33" fill="url(#plasterTopLight)" />
      <circle cx="0" cy="3" r="24" fill="url(#plasterBevel)" stroke="#FAF7F2" stroke-width="1.8" />
      <circle cx="0" cy="3" r="18" fill="url(#opticCavity)" />
    </g>
  </g>

  <!-- ========================================================================= -->
  <!-- 15. LOWER RIGHT: Large Pro DSLR with Zoom Lens on Shelf + Arcs -->
  <!-- ========================================================================= -->
  <g transform="translate(1380, 890)">
    <g filter="url(#shelfDropShadow)">
      <rect x="-140" y="56" width="195" height="13" rx="2" fill="url(#plasterTopLight)" />
      <rect x="-140" y="56" width="195" height="2.5" fill="#FFFFFF" opacity="0.8" />
    </g>
    <g filter="url(#deepDropShadow)">
      <!-- Main Body -->
      <rect x="-38" y="-60" width="140" height="115" rx="11" fill="url(#plasterBevel)" stroke="#FAF7F2" stroke-width="1" />
      <!-- Ergonomic Handgrip -->
      <path d="M 102,-44 Q 120,-22 120,22 Q 120,48 102,54 Z" fill="url(#plasterShade)" />
      <!-- Pentaprism Hump -->
      <polygon points="6,-60 30,-82 56,-60" fill="url(#plasterTopLight)" stroke="#FAF7F2" stroke-width="1" />
      <!-- Big Forward Angled Zoom Lens -->
      <g transform="translate(-52, -2)">
        <rect x="-48" y="-44" width="65" height="88" rx="7" fill="url(#barrelVert)" />
        <ellipse cx="-48" cy="0" rx="18" ry="44" fill="url(#plasterBevel)" stroke="#FAF7F2" stroke-width="2" />
        <ellipse cx="-48" cy="0" rx="13.5" ry="35" fill="url(#opticCavity)" />
        <ellipse cx="-48" cy="0" rx="8" ry="20" fill="#7E7566" />
        <rect x="-26" y="-46" width="24" height="92" rx="2" fill="url(#plasterTopLight)" />
      </g>
    </g>
  </g>

  <!-- ========================================================================= -->
  <!-- 16. FAR-RIGHT: 3-Axis Motorized Gimbal Stabilizer & Mini Prime Lens -->
  <!-- ========================================================================= -->
  <g transform="translate(1660, 730)">
    <g filter="url(#deepDropShadow)">
      <!-- Tripod Base Feet -->
      <line x1="-30" y1="135" x2="0" y2="114" stroke="url(#plasterTopLight)" stroke-width="8" stroke-linecap="round" />
      <line x1="30" y1="135" x2="0" y2="114" stroke="url(#plasterTopLight)" stroke-width="8" stroke-linecap="round" />
      <line x1="0" y1="140" x2="0" y2="114" stroke="url(#plasterTopLight)" stroke-width="8" stroke-linecap="round" />
      <!-- Handle -->
      <rect x="-9" y="32" width="18" height="84" rx="5" fill="url(#barrelVert)" />
      <!-- Mechanical Gimbal Arm & Motors -->
      <circle cx="0" cy="24" r="13" fill="url(#plasterBevel)" />
      <path d="M 0,24 Q 30,20 30,-22 Q 30,-48 0,-48" fill="none" stroke="url(#plasterBevel)" stroke-width="11" stroke-linecap="round" />
      <rect x="-20" y="-38" width="40" height="30" rx="4" fill="url(#plasterBevel)" />
      <circle cx="-6" cy="-22" r="12" fill="url(#opticCavity)" />
    </g>
    <!-- Tiny Companion Lens on Shelf -->
    <g transform="translate(145, 65)">
      <g filter="url(#shelfDropShadow)">
        <rect x="-22" y="22" width="44" height="6.5" rx="2" fill="url(#plasterTopLight)" />
      </g>
      <g filter="url(#deepDropShadow)">
        <rect x="-15" y="-15" width="30" height="36" rx="2.5" fill="url(#barrelVert)" />
        <ellipse cx="0" cy="-15" rx="15" ry="5" fill="url(#plasterBevel)" />
        <ellipse cx="0" cy="-15" rx="10" ry="3.5" fill="url(#opticCavity)" />
      </g>
    </g>
  </g>

</svg>
`;

async function main() {
  const assetsDir = path.resolve(process.cwd(), 'public/assets');
  if (!fs.existsSync(assetsDir)) {
    fs.mkdirSync(assetsDir, { recursive: true });
  }

  const pngPath = path.join(assetsDir, 'immersive-camera-reference.png');
  const webpPath = path.join(assetsDir, 'immersive-camera-reference.webp');

  await sharp(Buffer.from(svgContent), { density: 150 })
    .png({ quality: 98, compressionLevel: 7 })
    .toFile(pngPath);

  await sharp(Buffer.from(svgContent), { density: 150 })
    .webp({ quality: 95 })
    .toFile(webpPath);

  console.log('Successfully generated reference background asset at:', pngPath);
}

main().catch(console.error);
